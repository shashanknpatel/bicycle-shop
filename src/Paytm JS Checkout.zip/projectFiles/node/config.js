
var MID = "qFdDse54533130099848";
var MKEY = "FmAbv&JHPrZevDpR";

var ENV= 'securegw-stage.paytm.in';
var WEBSITE= 'WEBSTAGING';

exports.MID = MID;
exports.MKEY = MKEY;
exports.ENV = ENV;
exports.WEBSITE = WEBSITE;